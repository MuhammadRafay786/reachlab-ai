# ReachLab AI — OpenAI Upgrade

An episode research tool for `MuhammadRafay786/reachlab-ai`. Streamlit Community Cloud; **OpenAI Fast + Deep Verify + Gemini fallback**.

**Not the entire Agent-Reach toolkit.** ReachLab integrates its own YouTube/public social metadata flow, uploaded video frame processing, OpenAI, Gemini fallback, and TVMaze. Agent-Reach's browser-authenticated X/Instagram/Reddit features are **not** present on the Streamlit server.

## What this version changes

- **OpenAI fast mode:** `gpt-4.1-mini` (configure `OPENAI_FAST_MODEL`). Optional screenshots and up to eight sampled video frames attached via the Responses API.
- **Deep verify button:** a separate `gpt-4.1` web-search API request (`OPENAI_VERIFY_MODEL`). Queries scene/dialogue and returns potential sources. **Search cannot guarantee that a clip belongs to an episode.** Deep mode is opt-in and can cost more.
- **YouTube Short link only:** reads accessible public metadata and caption tracks **without downloading full video**. If YouTube blocks access or captions are missing, add your own screenshot, short video upload, or distinctive dialogue. OpenAI does not simply watch a YouTube URL.
- **Uploaded videos:** accepts 45 MB max in MP4/MOV/WEBM/M4V; samples up to 8 frames from first 90 seconds using `imageio-ffmpeg` on the server. Temporary files are deleted after sampling. Optionally transcribe uploaded speech using `gpt-4o-mini-transcribe` for an additional billed API request. Upload content only if you have authorization to process it.
- **Gemini fallback:** existing Gemini behavior for video URLs and screenshots, if a `GEMINI_API_KEY` is configured. Fallback may incur quota/usage costs too.
- **TVMaze:** verifies only existence of an episode LISTING, not a match to the video. Known-season hints flag contradictions; results are clearly **UNVERIFIED** without scene-specific evidence.
- **Caching:** per-Streamlit-session caching of last 8 results; repeated identical requests skip AI analysis. No shared cache across users or persistent video storage.

## GitHub upload (replace existing project files)

1. Extract ZIP (do **not** upload the ZIP itself).
2. Go to <https://github.com/MuhammadRafay786/reachlab-ai> → **Add file** → **Upload files**.
3. Upload **all top-level project files** (`app.py`, `reachlab.py`, `openai_backend.py`, `media_utils.py`, `requirements.txt`, `README.md`, `.gitignore`). You can optionally upload `tests/` as a folder using GitHub Desktop/Git; tests are not required to deploy.
4. Confirm `app.py` and `requirements.txt` are at repository **root**, not in a nested ZIP folder. Commit changes to `main`. Streamlit Community Cloud usually rebuilds automatically after the push; reboot app from Streamlit dashboard if needed.
5. **Never commit `secrets.toml` or any API keys.** This project intentionally does not contain a `.streamlit/secrets.toml` file.

## Streamlit Cloud secrets

Streamlit workspace → ReachLab app → **Settings → Secrets**. Add TOML lines (each value on a single line):

```toml
APP_PASSWORD = "REPLACE_WITH_NEW_UNIQUE_16_PLUS_CHARACTER_PASSWORD"
OPENAI_API_KEY = "REPLACE_WITH_NEW_OPENAI_API_KEY"
OPENAI_FAST_MODEL = "gpt-4.1-mini"
OPENAI_VERIFY_MODEL = "gpt-4.1"

# Optional fallback only, can omit both:
GEMINI_API_KEY = "REPLACE_WITH_NEW_GEMINI_KEY"
GEMINI_MODEL = "gemini-2.5-flash"
```

For an **OpenAI-only** configuration, remove both GEMINI lines entirely. Don't keep literal placeholder secrets. Change compromised keys before enabling the public app. A ChatGPT subscription does not cover OpenAI API costs: enable API billing and set project budget alerts at <https://platform.openai.com/settings/organization/billing/overview>.

Models used here are documented OpenAI API model IDs, not ChatGPT display labels. API model permissions, pricing, quota, and web-search availability depend on your account.

## Setup / local test (Windows PowerShell)

```powershell
cd "$HOME\ReachLab_OpenAI_Upgrade"
py -3 -m venv .venv
& ".\.venv\Scripts\python.exe" -m pip install -r requirements.txt
$env:APP_PASSWORD = Read-Host "New strong app password"
$env:OPENAI_API_KEY = Read-Host "OpenAI API key"
& ".\.venv\Scripts\python.exe" -m streamlit run app.py
```

**Do not share screenshots of API keys or passwords.**

## Verification plan

1. Enter your known Family Guy season-19 clip. Try link-only first; if there are no captions, upload an authorized 15–60-second clip or a screenshot plus a distinctive dialogue line.
2. Fast analysis shows a candidate episode with an **Unverified** label; check visual/audio evidence reported by the UI.
3. Click **Search for matching scene evidence** (extra API charge). Compare transcript/scene evidence with episode guide and actual episode footage before using the result.
4. Do not publish a wrong season/episode as verified. For videos without enough evidence, app should say **Not identified** or **Unverified candidate**.

## Limitations and safety

- There are no guarantees about speed or correct episode identification: video decoding, YouTube restrictions, external APIs, or web search may take time/fail.
- Public YouTube/Instagram/Reddit access is *best effort*. A link alone may not have captions or visual evidence; cookie-based agent features and full authenticated platform access are not integrated.
- Password gate is a small friends-only MVP, **not** a production-grade login/rate limiting system. Do not publicly share the password or invite arbitrary users; set low API spending limits, monitor billing, and move to OAuth/rate limiting before wider launch.
- API keys are stored in Streamlit Secrets, not in the public GitHub repo. Temporary uploaded video files are removed when processing completes, but the models/services receive any data you send for analysis.
- Upload or process third-party video only where you have rights/permission; finding an episode does not grant reuse rights for a clipping channel.

## Docs

- OpenAI Responses API + image inputs: https://platform.openai.com/docs/guides/images-vision
- OpenAI web search: https://platform.openai.com/docs/guides/tools-web-search
- OpenAI models: https://platform.openai.com/docs/models/gpt-4.1-mini
- Streamlit deploy: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy
- Streamlit secrets: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/secrets-management
- Original Agent-Reach: https://github.com/Panniantong/Agent-Reach
