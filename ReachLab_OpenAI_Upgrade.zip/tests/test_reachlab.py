"""Offline tests: no API credits, network, or Streamlit session required."""
import json
import sys
import types
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from reachlab import (decode_json_response, episode_match_status, normalize_url,
                      tvmaze_verify)
from media_utils import extract_video_frames_and_audio, caption_text


@pytest.fixture(autouse=True)
def fake_openai_sdk(monkeypatch):
    try:
        from openai import OpenAI
    except ImportError:
        monkeypatch.setitem(sys.modules, "openai", types.SimpleNamespace(OpenAI=object))


def test_youtube_link_valid():
    assert normalize_url("https://youtube.com/shorts/Cq7gX2jtgy0") == "https://youtube.com/shorts/Cq7gX2jtgy0"


@pytest.mark.parametrize("url", [
    "http://youtube.com/shorts/aaa", "https://youtube.com.evil.org/x",
    "https://127.0.0.1:11434/", "file:///etc/passwd",
    "https://username:password@youtube.com/shorts/x",
])
def test_rejects_unsafe_links(url):
    with pytest.raises(ValueError):
        normalize_url(url)


def test_json_fences_and_invalid():
    assert decode_json_response('```json\n{"show": "Family Guy"}\n```')["show"] == "Family Guy"
    with pytest.raises(ValueError):
        decode_json_response("Sorry, I do not know.")


def test_catalog_listing_does_not_prove_clip():
    result = {"show": "Family Guy", "season": 20, "episode": 13}
    listing = {"status": "episode_listing_confirmed", "title": "Lawyer Guy"}
    assert episode_match_status(result, listing)["label"] == "Unverified candidate"
    mismatch = episode_match_status(result, listing, 19)
    assert mismatch["conflict"] is True
    assert mismatch["label"] == "Conflicting candidate"


def test_openai_framed_input_is_structured():
    from openai_backend import analyze_openai

    class Reply:
        output_text = json.dumps({
            "show": "Family Guy", "season": None, "episode": None,
            "clip_summary": "A short dialogue scene", "confidence": "low"
        })

    class Responses:
        def create(self, **kwargs):
            assert kwargs["model"] == "gpt-4.1-mini"
            assert kwargs["store"] is False
            parts = kwargs["input"][0]["content"]
            assert any(p["type"] == "input_image" for p in parts)
            assert "URL" in parts[0]["text"]
            return Reply()

    fake = types.SimpleNamespace(responses=Responses())
    result, label = analyze_openai("", "gpt-4.1-mini", "https://youtube.com/shorts/test",
                                  "A scene", "English", "Find episode", video_frames=[b"abc"], client=fake)
    assert result["season"] is None
    assert "1 sampled video frames" in label


def test_research_uses_web_search_and_citations():
    from openai_backend import research_openai

    class UrlCitation:
        url = "https://example.com/episode-transcript"
        title = "Scene transcript"

    class Block:
        annotations = [UrlCitation()]

    class Item:
        content = [Block()]

    class Reply:
        output_text = "UNVERIFIED — scene not matched"
        output = [Item()]

    class Responses:
        def create(self, **kwargs):
            assert kwargs["tools"] == [{"type": "web_search", "search_context_size": "low"}]
            return Reply()

    client = types.SimpleNamespace(responses=Responses())
    research = research_openai("", "gpt-4.1", {"show": "Family Guy", "clip_summary": "Peter speaks"},
                               "https://youtube.com/shorts/test", "dialogue", client=client)
    assert research["sources"][0]["url"] == "https://example.com/episode-transcript"


def test_video_size_and_extension_rejected_without_ffmpeg_run():
    with pytest.raises(ValueError):
        extract_video_frames_and_audio(b"test", "exe")
    with pytest.raises(ValueError):
        extract_video_frames_and_audio(b"z" * (45 * 1024 * 1024 + 1), "mp4")


def test_clip_audio_opt_in_only():
    from media_utils import transcribe_audio

    class Trans:
        def create(self, **kwargs):
            assert kwargs["model"] == "gpt-4o-mini-transcribe"
            assert kwargs["file"].name == "scene.mp3"
            return types.SimpleNamespace(text="It was the lobster scene")

    cli = types.SimpleNamespace(audio=types.SimpleNamespace(transcriptions=Trans()))
    assert "lobster" in transcribe_audio("", b"123", client=cli)
